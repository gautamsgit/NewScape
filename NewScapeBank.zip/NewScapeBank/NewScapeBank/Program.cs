﻿using NewScapeBank.Reports;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewScapeBank
{
    class Program
    {
        static void Main(string[] args)
        {
            DailySummaryReport dailySummaryReport = new DailySummaryReport();
            IEnumerable<BankReport> dailyReports= dailySummaryReport.getReport();
            Console.WriteLine("Acct      TotalCredits   TotalDebits");
            foreach(BankReport report in dailyReports)
            {
                Console.WriteLine(report.Acct+"\t\t"+report.TotalCredits+"\t\t"+report.TotalDebits);
            }

            
            Console.ReadLine();
        }
    }
}

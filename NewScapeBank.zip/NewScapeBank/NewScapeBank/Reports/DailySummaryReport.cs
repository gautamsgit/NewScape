﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewScapeBank.Reports
{
    class DailySummaryReport
    {
        public IEnumerable<BankReport> getReport()
        {
           IEnumerable<Bank> bankDailyTransactions= Utility.Utility.ReadFile();
           IEnumerable<BankReport> result = (from p in bankDailyTransactions
                                              group p by p.AccountNumber into g
                                              select new BankReport()
                                              {
                                                  Acct = g.Key,
                                                  TotalCredits = g.Sum(x => x.CreditAmount),
                                                  TotalDebits = g.Sum(x => x.DebitAmount)
                                              }).ToList();
            return result;
            
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewScapeBank.Reports
{
    class Bank
    {
        public DateTime TransactionDate { get; set; }
        public String AccountNumber { get; set; }
        public decimal CreditAmount { get; set; }
        public decimal DebitAmount { get; set; }
        public decimal ClosureAmount { get; set; }
    }

    class BankReport
    {
        public String Acct { get; set; }
        public decimal TotalCredits { get; set; }
        public decimal TotalDebits { get; set; }        
    }
}

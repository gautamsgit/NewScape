﻿using NewScapeBank.Reports;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace NewScapeBank.Utility
{
    class Utility
    {
        public static List<Bank> ReadFile()
        {
            List<Bank> listBank = new List<Bank>();
            string path = AppDomain.CurrentDomain.BaseDirectory.Replace("\\bin\\Debug\\", "");
            string[] lines = File.ReadAllLines(path+ "\\Files\\CreditDebitDetails.txt");
            foreach (string line in lines)
            {
                string[] col = line.Split(',');
                // process col[0], col[1], col[2]
                listBank.Add(new Bank() 
                                      { 
                                        TransactionDate= Convert.ToDateTime(col[0]),
                                        AccountNumber= col[1],
                                        CreditAmount= Convert.ToDecimal(col[2].Replace('-','0')),
                                        DebitAmount = Convert.ToDecimal(col[3].Replace('-', '0')),
                                        ClosureAmount= Convert.ToDecimal(col[4].Replace('-', '0'))
                                     }
                            );

            }
            return listBank;
        }
    }
}
